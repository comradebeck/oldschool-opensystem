<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
	<div id="divFooter">
		Power by <span id="spanOpenSystem"><a><?php echo GLOBAL_SYSTEM_TITLE; ?></a></span> Version <?php echo GLOBAL_SYSTEM_VERSION; ?>
	</div>

</body>
</html>