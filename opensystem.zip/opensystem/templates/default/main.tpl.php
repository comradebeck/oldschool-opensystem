<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
		<div id="divCenterMain">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
					<tr>
						<?php require_once(GLOBAL_INC_SIDEBAR); ?>
						<?php require_once(GLOBAL_INC_APPLICATION); ?>
					</tr>
				</tbody>
			</table>
		</div>	
	</div>
