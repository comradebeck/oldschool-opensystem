<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
						<td id="tdCenterMain_Right">
							<div id="idApplicationBox">
								<div id="divApplicationBox_Title"><?php echo $vApplicationName; ?></div>
								<div id="divApplicationBox_Content">
									<?php echo $vApplicationContent; ?>
								</div>
							</div>
						</td>
