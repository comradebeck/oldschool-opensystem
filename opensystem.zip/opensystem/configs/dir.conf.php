<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_DIR_FUNCTIONS', 				GLOBAL_DIR_ROOT.'functions/');
	define('GLOBAL_DIR_LIBRARIES', 				GLOBAL_DIR_ROOT.'libraries/');
	define('GLOBAL_DIR_TEMPLATES', 				GLOBAL_DIR_ROOT.'templates/default/');
	define('GLOBAL_DIR_INCLUDES', 				GLOBAL_DIR_ROOT.'includes/');
	define('GLOBAL_DIR_CLASSES', 				GLOBAL_DIR_ROOT.'classes/');
	define('GLOBAL_DIR_SYSTEMS', 				GLOBAL_DIR_ROOT.'sysapps/');
	define('GLOBAL_DIR_MODULES', 				GLOBAL_DIR_ROOT.'modapps/');
	define('GLOBAL_DIR_IMAGES', 				GLOBAL_DIR_ROOT.'images/');
	define('GLOBAL_DIR_CONFIGS', 				GLOBAL_DIR_ROOT.'configs/');
	define('GLOBAL_DIR_UPLOADS', 				GLOBAL_DIR_ROOT.'uploads/');
?>