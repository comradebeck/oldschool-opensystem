<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_IMG_LOGO', 					GLOBAL_URL_IMAGES.'imgSmartDigitalLogo.png');
	define('GLOBAL_IMG_FAVICON',				GLOBAL_URL_IMAGES.'imgFavIcon.png');

	define('GLOBAL_IMG_EDIT', 					GLOBAL_URL_IMAGES.'imgEdit.gif');
	define('GLOBAL_IMG_DELETE', 				GLOBAL_URL_IMAGES.'imgDelete.gif');
	define('GLOBAL_IMG_ENABLE', 				GLOBAL_URL_IMAGES.'imgEnable.gif');
	define('GLOBAL_IMG_DISABLE', 				GLOBAL_URL_IMAGES.'imgDisable.gif');
?>