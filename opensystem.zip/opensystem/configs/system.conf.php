<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_SYSTEM_TITLE', 				'Smart Digital');
	define('GLOBAL_SYSTEM_VERSION', 			'1.0 Alpha Release');
?>