<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_DB_HOST', 					'localhost');		// MySQL Database Server Hostname or IP Address
	define('GLOBAL_DB_USER', 					'root');			// Database Username
	define('GLOBAL_DB_PASS', 					'');				// Datbase Password
	define('GLONAL_DB_PREF', 					'');				// Table Prefix
	define('GLOBAL_DB_NAME', 					'dbopensystem');	// Database Name
	define('GLOBAL_DB_PORT', 					'3306');			// MySQL Port
?>