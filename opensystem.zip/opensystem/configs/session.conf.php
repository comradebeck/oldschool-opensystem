<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_SESSION_VALUE', 				1);
	define('GLOBAL_SESSION_KEY', 				'Global_Logged_In');
	define('GLOBAL_SESSION_USERINFOS',			'svActiveUserInfo');
	define('GLOBAL_SESSION_USERGRANTS', 		'svActiveUserGrants');
?>