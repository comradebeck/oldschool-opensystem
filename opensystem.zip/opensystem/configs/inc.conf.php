<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_INC_HEADER', 				GLOBAL_DIR_INCLUDES.'header.inc.php');
	define('GLOBAL_INC_MAIN', 					GLOBAL_DIR_INCLUDES.'main.inc.php');
	define('GLOBAL_INC_SIDEBAR',				GLOBAL_DIR_INCLUDES.'sidebar.inc.php');
	define('GLOBAL_INC_APPLICATION',			GLOBAL_DIR_INCLUDES.'application.inc.php');
	define('GLOBAL_INC_FOOTER', 				GLOBAL_DIR_INCLUDES.'footer.inc.php');
	define('GLOBAL_INC_SESSION', 				GLOBAL_DIR_INCLUDES.'session.inc.php');
	define('GLOBAL_INC_LOGIN', 					GLOBAL_DIR_INCLUDES.'login.inc.php');
?>