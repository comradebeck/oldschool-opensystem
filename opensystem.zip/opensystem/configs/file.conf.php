<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_FUNC_COMMON', 				GLOBAL_DIR_FUNCTIONS.'common.func.php');
	
	define('GLOBAL_CLASS_TABLE', 				GLOBAL_DIR_CLASSES.'table.class.php');
	define('GLOBAL_CLASS_DATABASE', 			GLOBAL_DIR_CLASSES.'database.class.php');
	define('GLOBAL_CLASS_INPUTFILTER', 			GLOBAL_DIR_CLASSES.'inputfilter.class.php');	
?>