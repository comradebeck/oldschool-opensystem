<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	$GLOBAL_FILTER_TAGS = array(				'applet', 	'body', 		'bgsound', 
												'base', 	'basefont', 	'embed', 
												'frame', 	'frameset', 	'head', 
												'html', 	'id', 			'iframe', 
												'ilayer', 	'layer', 		'link', 
												'meta', 	'name', 		'object', 
												'script', 	'style', 		'title', 
												'xml');
	$GLOBAL_FILTER_ATTRIBUTES = array(			'action', 	'background', 	'codebase', 
												'dynsrc', 	'lowsrc');
?>