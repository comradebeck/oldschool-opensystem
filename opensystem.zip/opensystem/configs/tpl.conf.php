<?php if (!defined('GLOBAL_BASE_CONFIG')) { die('Direct access to this file has been disallowed. Please contact your system administrator'); } ?>
<?php
	define('GLOBAL_TPL_HEADER', 				GLOBAL_DIR_TEMPLATES.'header.tpl.php');
	define('GLOBAL_TPL_MAIN', 					GLOBAL_DIR_TEMPLATES.'main.tpl.php');
	define('GLOBAL_TPL_SIDEBAR',				GLOBAL_DIR_TEMPLATES.'sidebar.tpl.php');
	define('GLOBAL_TPL_APPLICATION',			GLOBAL_DIR_TEMPLATES.'application.tpl.php');
	define('GLOBAL_TPL_FOOTER', 				GLOBAL_DIR_TEMPLATES.'footer.tpl.php');
	define('GLOBAL_TPL_LOGIN', 					GLOBAL_DIR_TEMPLATES.'login.tpl.php');
?>