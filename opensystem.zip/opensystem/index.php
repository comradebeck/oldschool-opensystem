<?php
	require('configure.php');
	require(GLOBAL_FUNC_COMMON);
	require(GLOBAL_INC_HEADER);
?>
	
<?php
	require(GLOBAL_INC_FOOTER);
?>