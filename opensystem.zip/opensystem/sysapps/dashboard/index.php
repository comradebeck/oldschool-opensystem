<?php
	require('../../configure.php');
	$vApplicationName = 'Dashboard';
	require(GLOBAL_FUNC_COMMON);	
	require(GLOBAL_INC_HEADER);
	require(GLOBAL_INC_MAIN);
	require(GLOBAL_INC_FOOTER);
?>